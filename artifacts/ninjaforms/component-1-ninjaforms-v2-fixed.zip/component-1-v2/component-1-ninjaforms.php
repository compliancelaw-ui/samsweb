<?php
/**
 * Plugin Name: Sam's OATH - Component 1: Ninja Forms (PHP 8.3 Compatible)
 * Description: TEST ONLY - Ninja Forms integration component
 * Version: 1.0.1-test
 * Requires PHP: 7.2
 */

if (!defined('WPINC')) {
    die;
}

// Set error reporting to catch everything
error_reporting(E_ALL);
ini_set('display_errors', '1');

define('SAMSOATH_COMPONENT1_DIR', plugin_dir_path(__FILE__));

// Register error handler to catch fatal errors
register_shutdown_function('component1_check_fatal_error');

function component1_check_fatal_error() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        update_option('component1_fatal_error', [
            'message' => $error['message'],
            'file' => $error['file'],
            'line' => $error['line'],
            'type' => $error['type']
        ]);
    }
}

// Try to load Ninja Forms integration
$component1_loaded = false;
$component1_error = null;

try {
    require_once SAMSOATH_COMPONENT1_DIR . 'samsoath-ninja-forms-integration.php';
    $component1_loaded = true;
    update_option('component1_loaded', true);
    delete_option('component1_error');
} catch (Throwable $e) {
    $component1_error = $e;
    update_option('component1_error', [
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ]);
}

add_action('admin_notices', 'component1_show_result');
function component1_show_result() {
    global $component1_loaded, $component1_error;
    
    // Check for fatal error from shutdown function
    $fatal_error = get_option('component1_fatal_error');
    if ($fatal_error) {
        ?>
        <div class="notice notice-error">
            <h3>✗ Component 1 (Ninja Forms Integration) - FATAL ERROR</h3>
            <p><strong>Error:</strong> <?php echo esc_html($fatal_error['message']); ?></p>
            <p><strong>File:</strong> <?php echo esc_html($fatal_error['file']); ?></p>
            <p><strong>Line:</strong> <?php echo esc_html($fatal_error['line']); ?></p>
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
        </div>
        <?php
        delete_option('component1_fatal_error');
        return;
    }
    
    // Check for caught exception
    $saved_error = get_option('component1_error');
    if ($saved_error) {
        ?>
        <div class="notice notice-error">
            <h3>✗ Component 1 (Ninja Forms Integration) FAILED</h3>
            <p><strong>Error:</strong> <?php echo esc_html($saved_error['message']); ?></p>
            <p><strong>File:</strong> <?php echo esc_html($saved_error['file']); ?></p>
            <p><strong>Line:</strong> <?php echo esc_html($saved_error['line']); ?></p>
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
            <details>
                <summary>Stack Trace (click to expand)</summary>
                <pre style="background: #f5f5f5; padding: 10px; overflow: auto;"><?php echo esc_html($saved_error['trace']); ?></pre>
            </details>
        </div>
        <?php
        return;
    }
    
    // Success
    if (get_option('component1_loaded')) {
        ?>
        <div class="notice notice-success">
            <h3>✓ Component 1 (Ninja Forms Integration) loaded successfully!</h3>
            <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
            <p><strong>Server:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></p>
        </div>
        <?php
    }
}
