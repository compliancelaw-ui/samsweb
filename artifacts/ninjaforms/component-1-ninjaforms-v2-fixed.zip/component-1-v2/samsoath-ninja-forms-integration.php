<?php
/**
 * SAM'S OATH - NINJA FORMS DATABASE INTEGRATION
 * 
 * Purpose: Connect Ninja Forms submissions to custom database tables
 * Installation: Add to theme's functions.php OR create as plugin
 * 
 * Forms handled:
 * - Take Sam's OATH (form ID will vary)
 * - Share Your Story (form ID will vary)
 * - Contact Us (form ID will vary)
 * 
 * @package SamsOATH
 * @version 1.0
 * @created February 17, 2026
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// ============================================================================
// CONFIGURATION - UPDATE THESE FORM IDs AFTER INSTALLATION
// ============================================================================
define('SAMSOATH_FORM_ID_OATH', 0);      // Replace with actual OATH form ID
define('SAMSOATH_FORM_ID_STORY', 0);     // Replace with actual Story form ID
define('SAMSOATH_FORM_ID_CONTACT', 0);   // Replace with actual Contact form ID

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Geocode city and state to latitude/longitude using Google Geocoding API
 * 
 * @param string $city
 * @param string $state
 * @return array ['lat' => float, 'lng' => float] or null if failed
 */
function samsoath_geocode_location($city, $state) {
    // Google Geocoding API key - store in wp-config.php for security
    $api_key = defined('GOOGLE_GEOCODING_API_KEY') ? GOOGLE_GEOCODING_API_KEY : '';
    
    if (empty($api_key)) {
        error_log('SAM\'S OATH: Google Geocoding API key not set');
        return null;
    }
    
    $address = urlencode($city . ', ' . $state . ', USA');
    $url = "https://maps.googleapis.com/maps/api/geocode/json?address={$address}&key={$api_key}";
    
    $response = wp_remote_get($url);
    
    if (is_wp_error($response)) {
        error_log('SAM\'S OATH Geocoding Error: ' . $response->get_error_message());
        return null;
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if ($body['status'] === 'OK' && !empty($body['results'][0])) {
        $location = $body['results'][0]['geometry']['location'];
        return [
            'lat' => $location['lat'],
            'lng' => $location['lng']
        ];
    }
    
    return null;
}

/**
 * Get pin color based on OATH category
 * 
 * @param string $category
 * @return string Hex color code
 */
function samsoath_get_pin_color($category) {
    $colors = [
        'struggling' => '#3EABA8', // Teal
        'memory'     => '#4A6FA5', // Blue
        'supporter'  => '#7AB87A', // Green
        'story'      => '#E8956F'  // Orange
    ];
    
    return isset($colors[$category]) ? $colors[$category] : $colors['supporter'];
}

/**
 * Process name for display based on name_type
 * 
 * @param string $name_type (full_name, first_name, initials, anonymous)
 * @param string $name_value
 * @return string Processed display name
 */
function samsoath_process_name_display($name_type, $name_value) {
    switch ($name_type) {
        case 'full_name':
            return sanitize_text_field($name_value);
            
        case 'first_name':
            $parts = explode(' ', trim($name_value));
            return sanitize_text_field($parts[0]);
            
        case 'initials':
            $parts = explode(' ', trim($name_value));
            $initials = '';
            foreach ($parts as $part) {
                if (!empty($part)) {
                    $initials .= strtoupper(substr($part, 0, 1)) . '.';
                }
            }
            return $initials;
            
        case 'anonymous':
        default:
            return 'A Friend of Sam';
    }
}

/**
 * Get user's IP address (respects proxies)
 * 
 * @return string IP address
 */
function samsoath_get_user_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return sanitize_text_field($ip);
}

// ============================================================================
// OATH FORM SUBMISSION HANDLER
// ============================================================================

/**
 * Handle Take Sam's OATH form submission
 * Saves to wp_oath_submissions table and triggers map update
 */
add_action('ninja_forms_after_submission', 'samsoath_handle_oath_submission');

function samsoath_handle_oath_submission($form_data) {
    global $wpdb;
    
    // Only process OATH form
    if ($form_data['form_id'] != SAMSOATH_FORM_ID_OATH) {
        return;
    }
    
    $fields = $form_data['fields'];
    
    // Extract field values (field IDs may vary - update these)
    $name_type = '';
    $name_value = '';
    $category = '';
    $city = '';
    $state = '';
    $email = '';
    $email_optin = false;
    
    foreach ($fields as $field) {
        $key = $field['key'];
        $value = $field['value'];
        
        switch ($key) {
            case 'name_type':
                $name_type = sanitize_text_field($value);
                break;
            case 'name_value':
                $name_value = sanitize_text_field($value);
                break;
            case 'oath_category':
                $category = sanitize_text_field($value);
                break;
            case 'city':
                $city = sanitize_text_field($value);
                break;
            case 'state':
                $state = sanitize_text_field($value);
                break;
            case 'email':
                $email = sanitize_email($value);
                break;
            case 'email_optin':
                $email_optin = !empty($value);
                break;
        }
    }
    
    // Process display name
    $name_display = samsoath_process_name_display($name_type, $name_value);
    
    // Get pin color
    $pin_color = samsoath_get_pin_color($category);
    
    // Geocode location
    $coords = samsoath_geocode_location($city, $state);
    $latitude = $coords ? $coords['lat'] : null;
    $longitude = $coords ? $coords['lng'] : null;
    $geocoded = $coords ? true : false;
    
    // Insert into database
    $table_name = $wpdb->prefix . 'oath_submissions';
    
    $inserted = $wpdb->insert(
        $table_name,
        [
            'name_type'       => $name_type,
            'name_value'      => $name_value,
            'name_display'    => $name_display,
            'category'        => $category,
            'city'            => $city,
            'state'           => $state,
            'latitude'        => $latitude,
            'longitude'       => $longitude,
            'geocoded'        => $geocoded,
            'email'           => $email,
            'email_optin'     => $email_optin,
            'ip_address'      => samsoath_get_user_ip(),
            'user_agent'      => sanitize_text_field($_SERVER['HTTP_USER_AGENT']),
            'submitted_at'    => current_time('mysql'),
            'map_pin_color'   => $pin_color,
            'visible_on_map'  => true
        ],
        [
            '%s', '%s', '%s', '%s', '%s', '%s',
            '%f', '%f', '%d', '%s', '%d', '%s',
            '%s', '%s', '%s', '%d'
        ]
    );
    
    if ($inserted) {
        $submission_id = $wpdb->insert_id;
        
        // Log success
        error_log("SAM'S OATH: New OATH submission #{$submission_id} - {$name_display} from {$city}, {$state}");
        
        // Trigger MapGeo refresh (if using cache)
        do_action('samsoath_oath_submitted', $submission_id);
        
        // Add to Mailchimp if opted in
        if ($email_optin && !empty($email)) {
            samsoath_add_to_mailchimp($email, $name_display, 'oath_optin');
        }
        
        // Send notification to Frank
        samsoath_notify_admin_new_oath($submission_id, $name_display, $city, $state);
        
    } else {
        error_log('SAM\'S OATH ERROR: Failed to insert OATH submission - ' . $wpdb->last_error);
    }
}

// ============================================================================
// STORY FORM SUBMISSION HANDLER
// ============================================================================

/**
 * Handle Share Your Story form submission
 * Saves to wp_story_submissions table with status 'pending'
 */
add_action('ninja_forms_after_submission', 'samsoath_handle_story_submission');

function samsoath_handle_story_submission($form_data) {
    global $wpdb;
    
    // Only process Story form
    if ($form_data['form_id'] != SAMSOATH_FORM_ID_STORY) {
        return;
    }
    
    $fields = $form_data['fields'];
    
    // Extract field values
    $name_display = '';
    $city = '';
    $state = '';
    $email = '';
    $title = '';
    $content = '';
    
    foreach ($fields as $field) {
        $key = $field['key'];
        $value = $field['value'];
        
        switch ($key) {
            case 'name_display':
                $name_display = sanitize_text_field($value);
                break;
            case 'city':
                $city = sanitize_text_field($value);
                break;
            case 'state':
                $state = sanitize_text_field($value);
                break;
            case 'email':
                $email = sanitize_email($value);
                break;
            case 'story_title':
                $title = sanitize_text_field($value);
                break;
            case 'story_content':
                $content = wp_kses_post($value); // Allow basic HTML, sanitize
                break;
        }
    }
    
    // Geocode location
    $coords = samsoath_geocode_location($city, $state);
    $latitude = $coords ? $coords['lat'] : null;
    $longitude = $coords ? $coords['lng'] : null;
    $geocoded = $coords ? true : false;
    
    // Create URL slug from title
    $slug = sanitize_title($title);
    
    // Count words
    $word_count = str_word_count(strip_tags($content));
    
    // Insert into database
    $table_name = $wpdb->prefix . 'story_submissions';
    
    $inserted = $wpdb->insert(
        $table_name,
        [
            'name_display'    => $name_display,
            'city'            => $city,
            'state'           => $state,
            'latitude'        => $latitude,
            'longitude'       => $longitude,
            'geocoded'        => $geocoded,
            'email'           => $email,
            'title'           => $title,
            'content'         => $content,
            'content_html'    => wpautop($content), // Add paragraph tags
            'word_count'      => $word_count,
            'status'          => 'pending',
            'slug'            => $slug,
            'submitted_at'    => current_time('mysql'),
            'ip_address'      => samsoath_get_user_ip(),
            'user_agent'      => sanitize_text_field($_SERVER['HTTP_USER_AGENT'])
        ],
        [
            '%s', '%s', '%s', '%f', '%f', '%d',
            '%s', '%s', '%s', '%s', '%d', '%s',
            '%s', '%s', '%s', '%s'
        ]
    );
    
    if ($inserted) {
        $submission_id = $wpdb->insert_id;
        
        error_log("SAM'S OATH: New story submission #{$submission_id} - '{$title}' by {$name_display}");
        
        // Send notification to Frank for review
        samsoath_notify_admin_new_story($submission_id, $title, $name_display);
        
        // Send confirmation to submitter if email provided
        if (!empty($email)) {
            samsoath_send_story_confirmation_email($email, $name_display, $title);
        }
        
    } else {
        error_log('SAM\'S OATH ERROR: Failed to insert story submission - ' . $wpdb->last_error);
    }
}

// ============================================================================
// CONTACT FORM SUBMISSION HANDLER
// ============================================================================

/**
 * Handle Contact form submission (all 4 types: general, workplace, speaking, press)
 * Saves to wp_contact_messages table
 */
add_action('ninja_forms_after_submission', 'samsoath_handle_contact_submission');

function samsoath_handle_contact_submission($form_data) {
    global $wpdb;
    
    // Only process Contact form
    if ($form_data['form_id'] != SAMSOATH_FORM_ID_CONTACT) {
        return;
    }
    
    $fields = $form_data['fields'];
    
    // Extract common fields
    $message_type = 'general';
    $name = '';
    $email = '';
    $phone = '';
    $message = '';
    $company = '';
    $company_size = '';
    
    foreach ($fields as $field) {
        $key = $field['key'];
        $value = $field['value'];
        
        switch ($key) {
            case 'message_type': // Radio button selection
                $message_type = sanitize_text_field($value);
                break;
            case 'name':
                $name = sanitize_text_field($value);
                break;
            case 'email':
                $email = sanitize_email($value);
                break;
            case 'phone':
                $phone = sanitize_text_field($value);
                break;
            case 'message':
                $message = sanitize_textarea_field($value);
                break;
            case 'company':
                $company = sanitize_text_field($value);
                break;
            case 'company_size':
                $company_size = sanitize_text_field($value);
                break;
        }
    }
    
    // Determine priority based on type
    $priority = ($message_type === 'press') ? 'high' : 'normal';
    
    // Insert into database
    $table_name = $wpdb->prefix . 'contact_messages';
    
    $inserted = $wpdb->insert(
        $table_name,
        [
            'message_type'    => $message_type,
            'name'            => $name,
            'email'           => $email,
            'phone'           => $phone,
            'company'         => $company,
            'company_size'    => $company_size,
            'message'         => $message,
            'status'          => 'unread',
            'priority'        => $priority,
            'submitted_at'    => current_time('mysql'),
            'ip_address'      => samsoath_get_user_ip(),
            'user_agent'      => sanitize_text_field($_SERVER['HTTP_USER_AGENT']),
            'referrer_url'    => isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : ''
        ],
        [
            '%s', '%s', '%s', '%s', '%s', '%s',
            '%s', '%s', '%s', '%s', '%s', '%s',
            '%s'
        ]
    );
    
    if ($inserted) {
        $message_id = $wpdb->insert_id;
        
        error_log("SAM'S OATH: New {$message_type} message #{$message_id} from {$name}");
        
        // Send notification to appropriate email based on type
        samsoath_notify_admin_new_message($message_id, $message_type, $name, $email);
        
        // Send confirmation to submitter
        samsoath_send_contact_confirmation_email($email, $name, $message_type);
        
    } else {
        error_log('SAM\'S OATH ERROR: Failed to insert contact message - ' . $wpdb->last_error);
    }
}

// ============================================================================
// EMAIL NOTIFICATION FUNCTIONS (Stubs - will complete after SMTP setup)
// ============================================================================

function samsoath_notify_admin_new_oath($id, $name, $city, $state) {
    // TODO: Send email to frank@samsoath.org
    // Subject: "New OATH Taker - {$name} from {$city}, {$state}"
}

function samsoath_notify_admin_new_story($id, $title, $author) {
    // TODO: Send email to frank@samsoath.org
    // Subject: "New Story Pending Review - '{$title}' by {$author}"
}

function samsoath_notify_admin_new_message($id, $type, $name, $email) {
    // TODO: Send email to appropriate address based on $type
    // workplace → workplace@samsoath.org
    // press → press@samsoath.org
    // speaking → speaking@samsoath.org
    // general → connect@samsoath.org
}

function samsoath_send_story_confirmation_email($to_email, $name, $title) {
    // TODO: Send from share@samsoath.org
    // Subject: "Story Received - We'll Review Within 48 Hours"
}

function samsoath_send_contact_confirmation_email($to_email, $name, $type) {
    // TODO: Send from appropriate address based on $type
    // Subject: "Thanks for reaching out - We'll respond within 24 hours"
}

function samsoath_add_to_mailchimp($email, $name, $segment) {
    // TODO: Mailchimp API integration
    // Add to appropriate list based on $segment
}

// ============================================================================
// ADMIN DASHBOARD HOOKS (for control panel)
// ============================================================================

// Register custom admin page for /frank-admin control panel
// This will be built as a separate file: samsoath-control-panel.php

?>
